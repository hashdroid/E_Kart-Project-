import { EkartClientPage } from './app.po';

describe('ekart-client App', () => {
  let page: EkartClientPage;

  beforeEach(() => {
    page = new EkartClientPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
