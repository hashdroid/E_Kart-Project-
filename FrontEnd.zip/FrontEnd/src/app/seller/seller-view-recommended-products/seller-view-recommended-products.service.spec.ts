import { TestBed, inject } from '@angular/core/testing';

import { SellerViewRecommendedProductsService } from './seller-view-recommended-products.service';

describe('SellerViewRecommendedProductsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SellerViewRecommendedProductsService]
    });
  });

  it('should be created', inject([SellerViewRecommendedProductsService], (service: SellerViewRecommendedProductsService) => {
    expect(service).toBeTruthy();
  }));
});
