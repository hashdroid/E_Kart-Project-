import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerViewRecommendedProductsComponent } from './seller-view-recommended-products.component';

describe('SellerViewRecommendedProductsComponent', () => {
  let component: SellerViewRecommendedProductsComponent;
  let fixture: ComponentFixture<SellerViewRecommendedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerViewRecommendedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerViewRecommendedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
