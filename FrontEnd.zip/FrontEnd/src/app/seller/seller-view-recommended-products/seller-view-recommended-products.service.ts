import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../../environments/environment';
import { RecommendedProduct } from '../../shared/models/recommendedProduct';
import { Seller } from '../../shared/models/seller';

@Injectable()
export class SellerViewRecommendedProductsService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  constructor(private http:Http) { }
  recommendProduct():Promise<any>
  {
    const url=environment.sellerRecommendedProductsAPI+"/view";
    return this.http.post(url,JSON.parse(sessionStorage.getItem("seller")),
    {headers:this.headers})
    .toPromise()
    .then(response=>response.json() as RecommendedProduct[])
    .catch(this.errorHandler);
  
  }
removeProduct(emailId:string,recommendedId):Promise<any>
{
  const url=environment.sellerRecommendedProductsAPI+"/remove/"+emailId+"/"+recommendedId;
  return this.http.post(url,recommendedId,{headers:this.headers})
  .toPromise()
  .then(response=>JSON.parse(JSON.stringify(response))._body)
  .catch(this.errorHandler);
}
  private errorHandler(error: any):Promise<any>
  {
      return Promise.reject(error.json() || error);
  }

}
