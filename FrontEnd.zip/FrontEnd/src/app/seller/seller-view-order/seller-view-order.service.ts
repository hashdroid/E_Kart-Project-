import { Injectable } from '@angular/core';
import { Orders } from '../../shared/models/order';
import { Http, Headers } from '@angular/http';
import { environment } from '../../../environments/environment';

@Injectable()
export class SellerViewOrderService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  constructor(private http: Http) { }

  getAllOrders(sellerEmailId): Promise<Orders[]> {
    const url = environment.sellerOrderAPI + "/viewOrders";
    return this.http.post(url, sellerEmailId, { headers: this.headers })
      .toPromise()
      .then(response => <Orders>response.json())
      .catch(this.errorHandler);

  }

  private errorHandler(error: any): Promise<any> {
    console.error("Error occured", error);
    return Promise.reject(error.message || error);
  }

  updateOrder(orderId, orderStatus)
    : Promise<any> {
    const url = environment.sellerOrderAPI + "/updateOrderStatus/" + orderId + "/" + orderStatus;
    return this.http.post(url, orderStatus, { headers: this.headers }).toPromise()
      .then(
      (response) => JSON.parse(JSON.stringify(response))._body
      ).catch(
      this.errorHandeler
      )
  }


  getAllOrderStatus(): Promise<string[]> {
    const url = environment.sellerOrderAPI + "/getAllOrderStatus";
    return this.http.get(url)
      .toPromise()
      .then((response) => <string[]>response.json())
      .catch(this.errorHandler)
  }



  private errorHandeler(error: any): Promise<any> {
    console.error("Error Occured:\n", error);
    return Promise.reject(JSON.parse(JSON.stringify(error)));
  }



}

