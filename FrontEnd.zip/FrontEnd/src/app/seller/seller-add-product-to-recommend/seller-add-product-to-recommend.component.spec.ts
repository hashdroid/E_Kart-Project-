import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerAddProductToRecommendComponent } from './seller-add-product-to-recommend.component';

describe('SellerAddProductToRecommendComponent', () => {
  let component: SellerAddProductToRecommendComponent;
  let fixture: ComponentFixture<SellerAddProductToRecommendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerAddProductToRecommendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAddProductToRecommendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
