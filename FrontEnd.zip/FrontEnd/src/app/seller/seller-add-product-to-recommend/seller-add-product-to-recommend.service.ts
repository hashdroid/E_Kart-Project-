import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Product } from '../../shared/models/product';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../../environments/environment';

@Injectable()
export class SellerAddProductToRecommendService {

  private headers=new Headers({ 'Content-Type': 'application/json' });

  constructor(private http:Http) { }

  displayAllProducts(seller):Promise<Product[]>{
    const url = environment.sellerRecommendedProductsAPI + "/displayAllProducts";
    return this.http.post(url,seller,{headers:this.headers})
    .toPromise()
    .then(response => <Product>response.json())
    .catch(this.errorHandler);
  }
  

  addNewRecommendation(productId,emailId):Promise<any>{
    const url=environment.sellerRecommendedProductsAPI + "/addProducts/" +emailId+ "/" +productId;
    return this.http.post(url,productId,{headers:this.headers})
    .toPromise()
    .then(response=>JSON.parse(JSON.stringify(response))._body)
    .catch(this.errorHandler);
  }

  private errorHandler(error:any):Promise<any>{
    return Promise.reject(error.message || error);
  }
  
}
