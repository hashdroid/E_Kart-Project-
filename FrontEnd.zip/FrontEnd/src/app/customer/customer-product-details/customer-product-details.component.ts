import { Component, OnInit, Input } from "@angular/core";
import { Product } from "../../shared/models/product";
import { CustomerSharedService } from "../customer-common-service";



@Component({
    selector: "customer-product-details",
    templateUrl: "./customer-product-details.component.html"
})
export class CustomerProductDetails implements OnInit {
    @Input()
    selectedProduct: Product;
    addToCart: boolean = false;
    ngOnInit(): void {
    }



}