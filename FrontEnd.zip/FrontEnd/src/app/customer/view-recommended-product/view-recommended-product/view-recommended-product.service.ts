import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../../../environments/environment';
import { RecommendedProdForCust } from '../../../shared/models/recommendedProdForCust';




@Injectable()
export class ViewRecommendedProductService {

  constructor(private http:Http) { }

  getRecommendedProduct():Promise<RecommendedProdForCust[]>{

    const url = environment.viewRecommendedProduct;
    return this.http.get(url)
      .toPromise()
      .then(response => response.json())
      .catch(this.errorHandeler);

  }
  private errorHandeler(error: any): Promise<any> {
    console.error("Error Occured:\n", error);
    return Promise.reject(JSON.parse(JSON.stringify(error)));
  }

}
