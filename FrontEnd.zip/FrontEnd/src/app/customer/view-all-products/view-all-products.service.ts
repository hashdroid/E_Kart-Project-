import { Injectable } from '@angular/core';
import { Http } from "@angular/http";

import 'rxjs/add/operator/toPromise';
import { Product } from '../../shared/models/product';

import { environment } from '../../../environments/environment';
import { Cart } from '../../shared/models/Cart';

@Injectable()
export class ViewAllProductsService {

  constructor(private http: Http) { }

  getAllProducts(): Promise<Product[]> {

    let url = environment.CustomerProductAPI + "/getAllProducts";
    return this.http.get(url)
      .toPromise()
      .then(response => response.json() as Product[])
      .catch(error => Promise.reject(error.json()))
  }

  addToCart(cart: Cart): Promise<Cart> {
    const url = environment.customerAPIUrl + '/customrLogin';
    return this.http.post("http://localhost:8765/EKart/CustomerCartAPI/addProductToCart", cart)
      .toPromise()
      //.then(function(response){return <Product[]>response.json()})
      .then(response => <Cart>response.json())
      .catch(error => Promise.reject(error.json()))
  }

}
