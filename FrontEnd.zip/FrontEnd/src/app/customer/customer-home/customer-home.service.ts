import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";
import { environment } from "../../../environments/environment";
import { Cart } from "../../shared/models/cart";



@Injectable()
export class CustomerHomeService {
    private headers = new Headers({ 'Content-Type': 'text/plain' });
    constructor(private http: Http) { }
    getCustomerCart(emailId: string): Promise<any> {
        let url: string = environment.customerCartUrl + "/getCustomerCart";
        return this.http.post(url, emailId, { headers: this.headers })
            .toPromise()
            .then(
            (response) => response.json() as Cart[]
            ).catch(
            this.errorHandeler
            )

    }



    private errorHandeler(error: any): Promise<any> {
        console.error("Error Occured:\n", error);
        return Promise.reject(error._body);
    }



}