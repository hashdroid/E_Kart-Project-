import { Component, OnInit } from "@angular/core";
import { Customer } from "../../shared/models/customer";
import { Router, ActivatedRoute } from "@angular/router";
import { CustomerHomeService } from "./customer-home.service";
import { Cart } from "../../shared/models/cart";
import { CustomerSharedService } from "../customer-common-service";


@Component({
    selector: 'customer-home',
    templateUrl: './../customer-home/customer-home.component.html',
    styleUrls: ['./customer-home.component.css']

})
export class CustomerHomeComponent {
    isViewProductSelected: boolean = false;
    optionSelected: string;
    loggedInCustomer: Customer;
    searchText: string;
    cart: Cart[] = [];


    constructor(private router: Router, private route: ActivatedRoute,
        private customerHomeService: CustomerHomeService, private customerSharedService: CustomerSharedService) {

    }

    ngOnInit() {

        this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
        this.getCustomerCart();

    }
    

    getAllProducts() {
        this.isViewProductSelected = !this.isViewProductSelected;
    }
  
    getCustomerCart() {
        this.customerSharedService.updatedCartList.subscribe(cartList => this.cart = cartList)
        this.customerHomeService.getCustomerCart(this.loggedInCustomer.emailId).then(
            cart => {
                this.cart = cart;
                sessionStorage.setItem("cart", JSON.stringify(this.cart));

            }
        ).catch(error => {
            console.log(error);
        })
    }
    chosenOptionValue = ""
    chosenOption(chosenOption: string) {

        this.chosenOptionValue = chosenOption
        this.optionSelected = chosenOption;
        if (chosenOption == "viewDetails") {
            this.router.navigate(["details"], { relativeTo: this.route });
        }
        else if (chosenOption == "cart") {
            this.router.navigate(["viewCart"], { relativeTo: this.route });
        } else if (chosenOption == "getAllProducts") {
            this.isViewProductSelected = true;
            this.router.navigate(["products"], { relativeTo: this.route });
        }
        else if(chosenOption=="viewRecommendedProduct"){
            this.isViewProductSelected=true;
            this.router.navigate(["viewRecommendedProductComponent"],{relativeTo:this.route});

        }
    }

    logout() {
        sessionStorage.clear();
        this.router.navigate([""])
    }
}