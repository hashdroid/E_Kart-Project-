package com.ekart.dao.test;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.CustomerCartDAO;
import com.ekart.model.CustomerCart;
import com.ekart.model.Product;

@ContextConfiguration(classes = SpringConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class CustomerCartDAOTest {
	
	@Autowired
	private CustomerCartDAO customerCartDAO;
	
	@Test
	public void getCustomerCartValid(){
		
		Assert.assertNotNull(customerCartDAO.getCustomerCart("tom@infosys.com"));
	}
	
	@Test
	public void getProductById(){
		
		Assert.assertNotNull(customerCartDAO.getProductById(1000));
	}
	
	@Test
	public void getProductByIdInvalid(){
		
		Assert.assertNull(customerCartDAO.getProductById(100000));
	}
	
	@Test
	public void deleteProductFromCart(){
		
		customerCartDAO.deleteProductFromCart("tom@infosys.com", 3000);
		
	}
	
	@Test
	public void modifyQuantityToCart(){
		
		customerCartDAO.modifyQuantityToCart(3000, 2);
	}
	
	@Test
	public void addProductToCart(){
		CustomerCart customerCart=new CustomerCart();
		customerCart.setCartId(3000);
		Product p =new Product();
		p.setProductId(1001);
		customerCart.setProduct(p);
		customerCart.setQuantity(1);
		customerCartDAO.addProductToCart("tom@infosys.com", customerCart);
	}

}
