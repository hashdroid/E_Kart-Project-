package com.ekart.service.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.CustomerRecommendationProductDAO;
import com.ekart.model.RecommendedProduct;
import com.ekart.service.CustomerRecommendationProductService;
import com.ekart.service.CustomerRecommendationProductServiceImpl;

@ContextConfiguration(classes = SpringConfig.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerProductRecommendationServiceTest {
	@Mock
	CustomerRecommendationProductDAO customerRecommendationProductDAO;
	
	@InjectMocks
	CustomerRecommendationProductService customerRecommendationProductService=new CustomerRecommendationProductServiceImpl();
	
	@Rule
	public ExpectedException expectedException=ExpectedException.none();
	
	@Test
	public void viewRecommendedProductValidServiceTest()throws Exception{
		List<RecommendedProduct> recommendedProductList=new ArrayList<>();
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000001);
		recommendedProductList.add(recommendedProduct);
		Mockito.when(customerRecommendationProductDAO.viewRecommendedProduct()).thenReturn(recommendedProductList);
		Assert.assertEquals(recommendedProductList,customerRecommendationProductService.viewRecommendedProduct());
	}

	@Test
	public void viewRecommendedProductInvalidServiceTest()throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("CustomerRecommendationProductService.NO_DEALS");
		List<RecommendedProduct> recommendedProductList=new ArrayList<>();
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000000);
		recommendedProductList.add(recommendedProduct);
		Mockito.when(customerRecommendationProductDAO.viewRecommendedProduct()).thenReturn(null);
		customerRecommendationProductService.viewRecommendedProduct();
	}
}
