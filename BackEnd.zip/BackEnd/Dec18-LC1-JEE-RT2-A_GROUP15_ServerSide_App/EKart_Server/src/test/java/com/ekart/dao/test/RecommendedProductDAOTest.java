package com.ekart.dao.test;



import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.RecommendedProductDAO;
import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;
import com.ekart.model.Seller;


@ContextConfiguration(classes = SpringConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class RecommendedProductDAOTest {
	@Autowired
	private RecommendedProductDAO  recommendedProductDAO;
	
	@Test
	public void getRecommendedProductsValidTest(){
		Seller seller=new Seller();
		seller.setEmailId("ken@infosys.com");
		Assert.assertNotNull(recommendedProductDAO.getRecommendedProducts(seller.getEmailId()));
	}
	
	@Test
	public void getRecommendedProductsInvalidTest(){
		Seller seller=new Seller();
		seller.setEmailId("ken@inf.co");
		Assert.assertNull(recommendedProductDAO.getRecommendedProducts(seller.getEmailId()));
	}
	
	@Test
	public void removeRecommendedProductsValidTest(){
		Seller seller=new Seller();
		seller.setEmailId("mark@infosys.com");
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000001);
		Integer recommendationId=recommendedProductDAO.removeRecommendedProducts(seller.getEmailId(), recommendedProduct.getrecommendationId());
		Assert.assertNotNull(recommendationId);
	}
	
	@Test
	public void removeRecommendedProductsInvalidTest(){
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000000);
		Integer recommendationId=recommendedProductDAO.removeRecommendedProducts(seller.getEmailId(),recommendedProduct.getrecommendationId());
		Assert.assertNotEquals(recommendationId, recommendedProduct.getrecommendationId());
	}
	
	@Test 
	public void addRecommendedProductsValidTest(){
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		Product product=new Product();
		product.setProductId(1041);
		Integer id =recommendedProductDAO.addRecommendedProducts(seller.getEmailId(), product.getProductId());
		Assert.assertNotNull(id);
	}
	
	@Test
	public void getAllProductsValidTest(){
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		List<Product> productList=recommendedProductDAO.getAllProducts(seller.getEmailId());
		Assert.assertNotNull(productList);
	}
	
	
}
