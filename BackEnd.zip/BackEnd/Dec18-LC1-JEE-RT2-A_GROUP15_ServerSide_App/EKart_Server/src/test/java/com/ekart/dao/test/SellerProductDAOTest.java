package com.ekart.dao.test;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ekart.dao.SellerProductDAO;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.configuration.SpringConfig;
import com.ekart.entity.ProductCategoryEntity;
import com.ekart.model.Product;
import com.ekart.model.Seller;


@ContextConfiguration(classes = SpringConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class SellerProductDAOTest {
	
	@Autowired
	private SellerProductDAO sellerProductDAO;

	@Test
	public void modifyProductDetails(){
		Seller seller=new Seller();
		List<Product> products=new ArrayList<>();
		Product product=new Product();
		product.setBrand("Samsung");
		product.setCategory("Mobile");
		product.setDescription("12MP camera");
		product.setDiscount(10.0);
		product.setName("Galaxy");
		product.setPrice(18500.0);
		product.setProductId(1005);
		product.setQuantity(10);
		
		products.add(product);
		seller.setProducts(products);
		sellerProductDAO.modifyProductDetails(product, "jack@infosys.com");
		Assert.assertTrue(true);
	}
	
	@Test
	public void addNewProduct(){
		Seller seller=new Seller();
		List<Product> products=new ArrayList<>();
		Product product=new Product();
		product.setBrand("Samsung");
		product.setCategory("Mobile");
		product.setDescription("12MP camera");
		product.setDiscount(10.0);
		product.setName("Galaxy");
		product.setPrice(18500.0);
		product.setProductId(1005);
		product.setQuantity(10);
		
		products.add(product);
		seller.setProducts(products);
		sellerProductDAO.addNewProduct(product, "jack@infosys.com");
		Assert.assertTrue(true);
	}
	
	@Test
	public void removeProduct(){
		Seller seller=new Seller();
		List<Product> products=new ArrayList<>();
		Product product=new Product();
		product.setBrand("Samsung");
		product.setCategory("Mobile");
		product.setDescription("12MP camera");
		product.setDiscount(10.0);
		product.setName("Galaxy");
		product.setPrice(18500.0);
		product.setProductId(1005);
		product.setQuantity(10);
		
		products.add(product);
		seller.setProducts(products);
		sellerProductDAO.removeProduct(product.getProductId(), "jack@infosys.com");
		Assert.assertTrue(true);
	}
	
	@Test
	public void getProductCategoryList(){
		List<ProductCategoryEntity> productCategoryEntityList=new ArrayList<>();
		List<String> productCategories = new ArrayList<>();
		
		for (ProductCategoryEntity productCategoryEntity : productCategoryEntityList) {
			productCategories.add(productCategoryEntity.getCategory());
		}
	
		sellerProductDAO.getProductCategoryList();
		Assert.assertTrue(true);
	}
	
	
	
}
