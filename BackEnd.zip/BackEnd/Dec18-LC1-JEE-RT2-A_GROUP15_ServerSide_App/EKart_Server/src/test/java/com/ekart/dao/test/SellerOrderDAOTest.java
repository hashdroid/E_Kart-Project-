package com.ekart.dao.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.SellerOrderDAO;
import com.ekart.model.OrderStatus;
//admin@vjeemys-09:5555/gitblit/r/EKart_Server_Side_Maven.git
import org.junit.Assert;
import org.junit.Test;


@ContextConfiguration(classes = SpringConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class SellerOrderDAOTest {
	
	@Autowired
	private SellerOrderDAO sellerOrderDAO;
	
	@Test

	public void testModifyOrderStatus(){
		sellerOrderDAO.modifyOrderStatus(90000, OrderStatus.CANCELLED);
	}
	
	@Test
	public void testGetOrdersForProducts(){
		List<Integer> productId=new ArrayList<Integer>();
		productId.add(1044);
		productId.add(1052);
		Assert.assertNotNull(sellerOrderDAO.getOrdersForProducts(productId));
	}
}


