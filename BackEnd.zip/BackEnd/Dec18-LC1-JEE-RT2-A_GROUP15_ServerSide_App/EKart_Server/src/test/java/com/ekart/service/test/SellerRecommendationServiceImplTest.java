package com.ekart.service.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.RecommendedProductDAO;
import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;
import com.ekart.model.Seller;
import com.ekart.service.SellerRecommendationsService;
import com.ekart.service.SellerRecommendationsServiceImpl;

@ContextConfiguration(classes=SpringConfig.class)
@RunWith (MockitoJUnitRunner.class)
public class SellerRecommendationServiceImplTest {
	@Mock
	RecommendedProductDAO recommendedProductDAO;
	
	@InjectMocks
	 SellerRecommendationsService serviceImpl=new SellerRecommendationsServiceImpl();
	
	@Rule
	public ExpectedException expectedException=ExpectedException.none();
	
	@Test
	public void getRecommendedProductsServiceTest() throws Exception{
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		List<RecommendedProduct>recommendationList=new ArrayList<>();
		Product  product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		recommendedProduct.setrecommendationId(500000);
		recommendedProduct.setProduct(product);
		recommendationList.add(recommendedProduct);
		Seller seller=new Seller();
		seller.setRecommendedProducts(recommendationList);
		seller.setEmailId("jack@infosys.com");
		Mockito.when(recommendedProductDAO.getRecommendedProducts(seller.getEmailId())).thenReturn(recommendationList);
		Assert.assertNotNull(serviceImpl.getRecommendedProducts(seller.getEmailId()));
	}
	
	
	@Test
	public void getRecommendedProductsServiceRecommendationInvalidTest() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerRecommendationsService.INVALID_EMAIL_ID");
		Seller seller=new Seller();
		seller.setEmailId("abc@infosys.com");
		Mockito.when(recommendedProductDAO.getRecommendedProducts(seller.getEmailId())).thenReturn(null);
		serviceImpl.getRecommendedProducts(seller.getEmailId());	
	}
	
	@Test
	public void removeRecommendationServiceValidTest() throws Exception{
		Seller seller=new Seller();
		seller.setEmailId("mark@infosys.com");
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000001);
		Mockito.when(recommendedProductDAO.removeRecommendedProducts(seller.getEmailId(), recommendedProduct.getrecommendationId()))
		.thenReturn(recommendedProduct.getrecommendationId());
		Assert.assertNotNull(serviceImpl.removeRecommendedProducts(seller.getEmailId(), recommendedProduct.getrecommendationId()));
	}
	
	@Test
	public void removeRecommendationServiceInvalidTest() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerRecommendationsService.ALREADY_REMOVED");
		Seller seller=new Seller();
		seller.setEmailId("mark@infosys.com");
		RecommendedProduct recommendedProduct=new RecommendedProduct();
		recommendedProduct.setrecommendationId(5000001);
		Mockito.when(recommendedProductDAO.removeRecommendedProducts(seller.getEmailId(), recommendedProduct.getrecommendationId()))
		.thenReturn(null);
		serviceImpl.removeRecommendedProducts(seller.getEmailId(), recommendedProduct.getrecommendationId());

	}
	
	@Test
	public void addRecommendedProductsValidServiceTest() throws Exception{
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(recommendedProductDAO.addRecommendedProducts(seller.getEmailId(), product.getProductId()))
		.thenReturn(product.getProductId());
		Assert.assertNotNull(serviceImpl.addRecommendedProducts(seller.getEmailId(), product.getProductId()));
	}
	
	@Test
	public void addRecommendedProductsInvalidServiceTest() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("SellerRecommendationsService.NO_RECORDS_FOUND");
		Seller seller=new Seller();
		seller.setEmailId("abc@infosys.com");
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(recommendedProductDAO.addRecommendedProducts(seller.getEmailId(), product.getProductId()))
		.thenReturn(null);
		serviceImpl.addRecommendedProducts(seller.getEmailId(), product.getProductId());
	}
	
	@Test
	public void getAllProductsValidTest() throws Exception{
		Seller seller=new Seller();
		seller.setEmailId("jack@infosys.com");
		List<Product> productList=recommendedProductDAO.getAllProducts(seller.getEmailId());
		Assert.assertEquals(productList, serviceImpl.getAllProducts(seller.getEmailId()));
	}

}
