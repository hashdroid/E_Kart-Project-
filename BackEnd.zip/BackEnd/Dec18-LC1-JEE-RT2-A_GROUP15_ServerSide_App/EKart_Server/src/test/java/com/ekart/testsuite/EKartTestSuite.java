package com.ekart.testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.ekart.dao.test.CustomerCartDAOTest;
import com.ekart.dao.test.CustomerDAOTest;
import com.ekart.dao.test.CustomerProductDAOTest;
import com.ekart.dao.test.SellerDAOTest;
import com.ekart.dao.test.SellerOrderDAOTest;
import com.ekart.dao.test.SellerProductDAOTest;
import com.ekart.service.test.CustomerCartServiceTest;
import com.ekart.service.test.CustomerProductServiceTest;
import com.ekart.service.test.CustomerServiceTest;
import com.ekart.service.test.SellerOrderServiceTest;
import com.ekart.service.test.SellerProductServiceTest;
import com.ekart.service.test.SellerServiceTest;
import com.ekart.validator.test.CustomerValidatorTest;
import com.ekart.validator.test.SellerProductValidatorTest;
import com.ekart.validator.test.SellerValidatorTest;


@RunWith(Suite.class)
@Suite.SuiteClasses({

	CustomerValidatorTest.class,
	SellerProductValidatorTest.class,
	SellerValidatorTest.class,
	
	CustomerCartDAOTest.class,
	CustomerDAOTest.class,
	CustomerProductDAOTest.class,
	SellerDAOTest.class,
	SellerOrderDAOTest.class,
	SellerProductDAOTest.class,
	
	CustomerCartServiceTest.class,
	CustomerProductServiceTest.class,
	CustomerServiceTest.class,
	SellerOrderServiceTest.class,
	SellerProductServiceTest.class,
	SellerServiceTest.class
	
	 })

public class EKartTestSuite {

}
