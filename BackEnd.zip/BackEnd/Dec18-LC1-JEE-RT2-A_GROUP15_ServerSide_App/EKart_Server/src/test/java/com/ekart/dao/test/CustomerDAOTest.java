package com.ekart.dao.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.configuration.SpringConfig;
import com.ekart.dao.CustomerDAO;
import com.ekart.model.Address;
import com.ekart.model.Customer;
import com.ekart.utility.HashingUtility;

@ContextConfiguration(classes = SpringConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class CustomerDAOTest {
	@Autowired
	private CustomerDAO customerDAO;
	
	
	
	@Test
	public void checkRegisteredPhoneNumberValid() {
		Customer customer=new Customer();
		customer.setPhoneNumber("9988776655");
		customerDAO.checkRegisteredPhoneNumber(customer.getPhoneNumber());
		Assert.assertTrue(true);
		
	}
	
	@Test
	public void checkRegisteredPhoneNumberInValid() {
		Customer customer=new Customer();
		customer.setPhoneNumber("123ab45678");
		customerDAO.checkRegisteredPhoneNumber(customer.getPhoneNumber());
		Assert.assertFalse(false);
		
	}
	
	@Test
	public void checkAvailabilityOfEmailIdValid(){
		Customer customer=new Customer();
		customer.setEmailId("Fahad@infosys.com");
		customerDAO.checkAvailabilityOfEmailId(customer.getEmailId());
		Assert.assertTrue(true);
	}
	
	@Test
	public void checkAvailabilityOfEmailIdInValid(){
		Customer customer=new Customer();
		customer.setEmailId("Fa@had1992@infosys.com");
		customerDAO.checkAvailabilityOfEmailId(customer.getEmailId());
		Assert.assertFalse(false);
	}
	
	@Test 
	public void registerNewCustomerValidDetails() {
		Customer customer=new Customer();
		customer.setEmailId("Fahad@infosys.com");
		customer.setPassword("Fahad@123");
		customer.setName("Fahad Rahman");
		customer.setPhoneNumber("9988776655");
	
		customerDAO.registerNewCustomer(customer);
		Assert.assertTrue(true);
	}
	
	@Test 
	public void registerNewCustomerInValidDetails() {
		Customer customer=new Customer();
		customer.setEmailId("Fahad@infosys.com");
		customer.setPassword("Fahad@123");
		customer.setName("Fahad  rahman");
		customer.setPhoneNumber("9988776655");
	
		customerDAO.registerNewCustomer(customer);
		Assert.assertFalse(false);
	}
	
	@Test 
	public void updateCustomerValidDetails() {
		Customer customer=new Customer();
		customer=customerDAO.getCustomerByEmailId("mariya@infosys.com");
		customer.setName("Mariya M");
		customer.setPhoneNumber("7578116427");
	
		customerDAO.updateProfile(customer);
		Assert.assertTrue(true);
	}
	
	
	
	@Test
	public void changePasswordValidPassword() throws Exception{
		Customer customer = new Customer();
		String newHashedPassword=HashingUtility.getHashValue("JackP@123");
		customer.setPassword(newHashedPassword);
		customer.setEmailId("tom@infosys.com");
		customerDAO.changePassword(customer.getEmailId(), customer.getPassword());
		Assert.assertTrue(true);
	}
	
	@Test
	public void changePasswordInValidPassword() throws Exception{
		Customer customer = new Customer();
		String newHashedPassword=HashingUtility.getHashValue("J@123");
		customer.setPassword(newHashedPassword);
		customer.setEmailId("tom@infosys.com");
		customerDAO.changePassword(customer.getEmailId(), customer.getPassword());
		Assert.assertFalse(false);
	}
	
	
	@Test
	public void addShippingAddressValidDetails() throws Exception{
		Address address=new Address();
		address.setAddressId(5000);
		address.setAddressLine1("Ist Main, Building No.3");
		address.setAddressLine2("Park Square");
		address.setCity("Los Angeles");
		address.setContactNumber("7886189066");
		address.setState("California");
		address.setPin("752110");
		customerDAO.addShippingAddress("tom@infosys.com", address);
		
	}
	
	
	@Test
	public void getCustomerByPhoneNoValidDetails() throws Exception{
		customerDAO.getCustomerByPhoneNo("7886189067");
	}
	
	@Test
	public void getCustomerByPhoneNoInvalidDetails() throws Exception{
		customerDAO.getCustomerByPhoneNo("7886189066");
	}
	
	@Test
	public void deleteShippingAddressValidDetails() throws Exception{
		customerDAO.deleteShippingAddress("tom@infosys.com", 5000);
	}
	
	@Test
	public void updateShippingAddressValidDetails() throws Exception{
		Address address=new Address();
		address.setAddressId(5000);
		address.setAddressLine1("Ist Main, Building No.3");
		address.setAddressLine2("Park Square");
		address.setCity("Los Angeles");
		address.setContactNumber("7886189089");
		address.setState("California");
		address.setPin("752110");
		customerDAO.updateShippingAddress(address);
		
	}
	
	@Test
	public void getPasswordofCustomerValidDetails() {
		customerDAO.getPasswordOfCustomer("Tom@infosys.com");
		
	}
	
	
	
	@Test
	public void getCustomerbyEmailIdValidDetails() {
		customerDAO.getCustomerByEmailId("Tom@infosys.com");
	}
	@Test
	public void getCustomerbyEmailIdInValidDetails() {
		customerDAO.getCustomerByEmailId("T12");
	}

}
