package com.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.RecommendedProductDAO;
import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;

@Service(value = "sellerRecommendationsService")
@Transactional(readOnly=true)
public class SellerRecommendationsServiceImpl implements SellerRecommendationsService{
	
	@Autowired
	private RecommendedProductDAO recommendedProductDAO;
	
	@Override
	public List<RecommendedProduct> getRecommendedProducts(String emailId) throws Exception{
		List<RecommendedProduct> recommendedProducts=recommendedProductDAO.getRecommendedProducts(emailId);
		if(recommendedProducts==null){
			throw new Exception("SellerRecommendationsService.INVALID_EMAIL_ID");
		}
		else if(recommendedProducts.isEmpty()){
			throw new Exception("SellerRecommendationsService.NO_RECORDS_FOUND");
		}
		
		return recommendedProducts;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public String removeRecommendedProducts(String emailId, Integer recommendationId) throws Exception{
		Integer reqInt = recommendedProductDAO.removeRecommendedProducts(emailId, recommendationId);
		
		if(reqInt==null){
			throw new Exception("SellerRecommendationsService.ALREADY_REMOVED");
		}
		else{
			return reqInt.toString();
		}
		
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public Integer addRecommendedProducts(String emailId, Integer productId) throws Exception{
		Integer a=recommendedProductDAO.addRecommendedProducts(emailId, productId);
		if(a==null){
			throw new Exception("SellerRecommendationsService.NO_RECORDS_FOUND");
		}
		
		return a;
	}
	
	@Override
	public List<Product> getAllProducts(String emailId) throws Exception{
		List<Product> productList=recommendedProductDAO.getAllProducts(emailId);
		if(productList!=null){
			return productList;
		}
		else{
			throw new Exception("SellerRecommendationsService.EMPTY_RECOMMENDATION_LIST");
		}
	}

}
