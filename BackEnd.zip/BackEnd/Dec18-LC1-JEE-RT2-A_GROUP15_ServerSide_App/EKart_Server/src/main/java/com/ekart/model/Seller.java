package com.ekart.model;

import java.util.List;

public class Seller {

	private String emailId;
	private String name;
	private String password;
	private String newPassword;
	private String phoneNumber;
	private String address;
	private List<Product> products;
	private List<RecommendedProduct> recommendedProducts;
	private String errorMessage;
	
	
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public List<RecommendedProduct> getRecommendedProducts() {
		return recommendedProducts;
	}
	public void setRecommendedProducts(List<RecommendedProduct> recommendedProducts) {
		this.recommendedProducts = recommendedProducts;
	}

}
