package com.ekart.service;

import java.util.List;

import com.ekart.model.Product;

public interface CustomerProductService {
	public List<Product> getAllProducts() throws Exception;
}
