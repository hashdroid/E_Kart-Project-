package com.ekart.dao;

import com.ekart.model.Address;
import com.ekart.model.Customer;

public interface CustomerDAO {
	
	public String getPasswordOfCustomer(String emailId) ;
	public Customer getCustomerByEmailId(String emailId);
	public Boolean checkAvailabilityOfEmailId(String emailId);
	public Boolean checkRegisteredPhoneNumber(String phoneNumber);
	public String registerNewCustomer(Customer customer);
	
	public Customer getCustomerByPhoneNo(String phoneNumber);
	public void updateProfile(Customer customer);
	public void changePassword(String customerEmailId, String newHashedPassword);
	
	public Integer addShippingAddress(String customerEmailId, Address address);
	
	public void updateShippingAddress(Address address);
	
	public void deleteShippingAddress(String customerEmailId, Integer addressId);
	
}
