package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.CustomerCartEntity;
import com.ekart.entity.CustomerEntity;
import com.ekart.entity.ProductEntity;
import com.ekart.model.CustomerCart;
import com.ekart.model.Product;

@Repository(value = "customerCartDAO")
public class CustomerCartDAOImpl implements CustomerCartDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void addProductToCart(String customerEmailId, CustomerCart customerCart) {

		Session session = sessionFactory.getCurrentSession();
		
		CustomerCartEntity cartEntity = new CustomerCartEntity();
		
		ProductEntity productEntity = session.get(ProductEntity.class, customerCart.getProduct().getProductId());
		
		cartEntity.setProductEntity(productEntity);
		cartEntity.setQuantity(customerCart.getQuantity());
		
		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerEmailId);
		customerEntity.getCustomerCarts().add(cartEntity);
		
		session.save(customerEntity);
	}

	@Override
	public List<CustomerCart> getCustomerCart(String customerEmailId) {
		
		Session session  = sessionFactory.getCurrentSession();

		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerEmailId);
		List<CustomerCartEntity> cartEntities = customerEntity.getCustomerCarts(); 
		
		List<CustomerCart> listCustomerCart = new ArrayList<>();
		for (CustomerCartEntity customerCartEntity : cartEntities) {
			CustomerCart cart = new CustomerCart();
			cart.setCartId(customerCartEntity.getCartId());
			cart.setQuantity(customerCartEntity.getQuantity());
			ProductEntity productEntity = customerCartEntity.getProductEntity();
			
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setDiscount(productEntity.getDiscount());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			
			cart.setProduct(product);
			
			listCustomerCart.add(cart);
		}
		return listCustomerCart;
	}

	@Override
	public void modifyQuantityToCart(Integer cartId, Integer quantity) {
		
		Session session = sessionFactory.getCurrentSession();
		
		CustomerCartEntity cartEntity = session.get(CustomerCartEntity.class, cartId);
		
		cartEntity.setQuantity(quantity);
		
	}

	@Override
	public void deleteProductFromCart(String customerEmailId, Integer cartId) {

		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity = session.get(CustomerEntity.class, customerEmailId);
		List<CustomerCartEntity> carts = customerEntity.getCustomerCarts();
		CustomerCartEntity cartEntityToRemove = null;
		
		for (CustomerCartEntity customerCartEntity : carts) {
			if(cartId.equals(customerCartEntity.getCartId()))
			{
				cartEntityToRemove = customerCartEntity;
			}
		}
		carts.remove(cartEntityToRemove);
		
		CustomerCartEntity cartEntity = session.get(CustomerCartEntity.class, cartId);
		
		session.remove(cartEntity);
		
	}
	
	@Override
	public Product getProductById(Integer productId) {
		
		Product product =null;
		Session session = sessionFactory.getCurrentSession();
		ProductEntity productEntity = session.get(ProductEntity.class, productId);
		
		if (productEntity!=null){
			product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setDiscount(productEntity.getDiscount());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			
		}
		return product;
	}

}
