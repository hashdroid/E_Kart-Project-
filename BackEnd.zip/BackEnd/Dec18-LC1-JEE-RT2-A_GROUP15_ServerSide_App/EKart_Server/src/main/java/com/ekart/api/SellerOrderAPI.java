package com.ekart.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Order;
import com.ekart.model.OrderStatus;
import com.ekart.service.SellerOrderService;
import com.ekart.service.SellerOrderServiceImpl;
import com.ekart.utility.ContextFactory;
@CrossOrigin
@RestController
@RequestMapping("SellerOrderAPI")
public class SellerOrderAPI {

	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "viewOrders", method = RequestMethod.POST)
	public ResponseEntity<?> viewOrders(@RequestBody String sellerEmailId) throws Exception {

		try
		{
			SellerOrderService sellerOrderService = ContextFactory.getContext().getBean(SellerOrderServiceImpl.class);
			
			List<Order> orders = sellerOrderService.viewOrders(sellerEmailId);
			
			return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
	
	@RequestMapping(value = "updateOrderStatus/{orderId}/{orderStatus}", method = RequestMethod.POST)
	public ResponseEntity<String> updateOrderStatus(@PathVariable("orderId") Integer orderId, @PathVariable("orderStatus") String orderStatus) throws Exception {
		try
		{
			SellerOrderService sellerOrderService = ContextFactory.getContext().getBean(SellerOrderServiceImpl.class);
			
			sellerOrderService.modifyOrderStatus(orderId, orderStatus);
			
			String modificationSuccessMsg = environment.getProperty("SellerOrderAPI.ORDER_STATUS_UPDATE_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
	
	
	@RequestMapping(value = "getAllOrderStatus", method = RequestMethod.GET)
	public ResponseEntity<List<String>> getAllOrderStatus() {

			List<String> orderStatusList = new ArrayList<>();
			
			OrderStatus []orderStatus = OrderStatus.values();
			for (OrderStatus orderStatus2 : orderStatus) {
				orderStatusList.add(orderStatus2.toString());
			}
			
			return new ResponseEntity<List<String>>(orderStatusList, HttpStatus.OK);
			
	}
}
