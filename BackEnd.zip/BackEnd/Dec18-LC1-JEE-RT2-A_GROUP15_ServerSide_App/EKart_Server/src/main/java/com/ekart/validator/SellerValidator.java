package com.ekart.validator;

import com.ekart.model.Seller;

public class SellerValidator {
	
	public static void validateSellerForUpdateProfile(Seller seller) throws Exception{
		
		if( ! validateName(seller.getName()))
			throw new Exception("SellerValidator.INVALID_NAME");
		
		if( ! validatePhoneNumber(seller.getPhoneNumber()))
			throw new Exception("SellerValidator.INVALID_PHONE_NUMBER");
		
		if( ! validateAddress(seller.getAddress()))
			throw new Exception("SellerValidator.INVALID_ADDRESS");
	}
	
	/**
	 * This method is for validating the seller login details
	 * 
	 * @param emailId, password
	 * 
	 * @throws Exception
	 *  			if the email id of the seller is not matching the required format 
	 */

	public static void validateSellerForLogin(String emailId, String password) throws Exception{
		if( !validateEmailId(emailId) )
			throw new Exception("SellerValidator.INVALID_EMAIL_FORMAT");
		
		if( !validatePassword(password) )
			throw new Exception("SellerValidator.INVALID_PASSWORD_FORMAT");
	}

	public static void validateSellerForRegistration(Seller seller) throws Exception {
		if(!validateEmailId(seller.getEmailId()))
			throw new Exception("SellerValidator.INVALID_EMAIL_FORMAT");
		
		if(!validatePhoneNumber(seller.getPhoneNumber()))
			throw new Exception("SellerValidator.INVALID_PHONE_NUMBER");
		
		if(!validateName(seller.getName()))
			throw new Exception("SellerValidator.INVALID_NAME");
		
		if(!validatePassword(seller.getPassword()))
			throw new Exception("SellerValidator.INVALID_PASSWORD_FORMAT");
		
	}
	
	public static Boolean validateName(String name){
		Boolean flag = false;
		if(!name.matches("[ ]*") && name.matches("([A-Za-z])+(\\s[A-Za-z]+)*"))
			flag=true;
		return flag;
	}
	
	public static Boolean validatePhoneNumber(String phoneNumber){
		Boolean flag = false;
		if(phoneNumber.matches("[0-9]+") && phoneNumber.length()==10)
			flag=true;
		return flag;
	}
	
	public static Boolean validateAddress(String address){
		Boolean flag = false;
		if(address.length()>=10)
			flag=true;
		return flag;
	}
	
	/**
	 * This method validates the seller's emailId
	 * The first part of the emailId should be alphanumeric & followed by "@" then alphabets 
	 * followed by "." and alphabets.
	 * 
	 * @param emailId
	 * 
	 * @return true if the emailId is matching the above conditions, else
	 *         false.
	 */
	public static Boolean validateEmailId(String emailId){
		Boolean flag = false;
		if(emailId.matches("[a-zA-Z0-9._]+@[a-z]+\\.[a-z]+"))
			flag = true;
		return flag;
	}
	
	
	/**
	 * This method validates the customer's password
	 * The length of the password can be at least 6 characters to 20 characters long.
	 * 
	 * It should contain at least one Upper case character, one lower case character, one digit and a special character.
	 * 
	 * @param password
	 * 
	 * @return true if the password is matching the above conditions, else
	 *         false.
	 */
	
	public static Boolean validatePassword(String password){
		Boolean flag = false;
		if (password.length()>=6 && password.length()<=20)
			if(password.matches(".*[A-Z]+.*"))
				if(password.matches(".*[a-z]+.*"))
					if(password.matches(".*[0-9]+.*"))
						if(password.matches(".*[!@#$%^&*()].*"))
							flag = true;
		return flag;
	}


}
