package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.ProductEntity;
import com.ekart.entity.SellerEntity;
import com.ekart.model.Product;
import com.ekart.model.Seller;


@Repository(value = "sellerDAO")
public class SellerDAOImpl implements SellerDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public String getPasswordOfSeller(String emailId) {
		
		String password = null;
		emailId = emailId.toLowerCase();
		
		Session session = sessionFactory.getCurrentSession();
		SellerEntity sellerEntity = session.get(SellerEntity.class, emailId);
		
		if (sellerEntity!=null){
			password = sellerEntity.getPassword();
		}
		
		return password;
	}

	@Override
	public Seller getSellerByEmailId(String emailId) throws Exception {
		
		Seller seller = null;
		emailId = emailId.toLowerCase();
		List<Product> sellingProducts = new ArrayList<>();
		
		Session session = sessionFactory.getCurrentSession();
		SellerEntity sellerEntity = session.get(SellerEntity.class, emailId);
		if (sellerEntity!=null){
			seller = new Seller();
			seller.setAddress(sellerEntity.getAddress());
			seller.setEmailId(sellerEntity.getEmailId());
			seller.setName(sellerEntity.getName());
			//seller.setPassword(sellerEntity.getPassword());
			seller.setPhoneNumber(sellerEntity.getPhoneNumber());
			for (ProductEntity i : sellerEntity.getProductEntities()) {
				Product p = new Product();
				p.setBrand(i.getBrand());
				p.setCategory(i.getCategory());
				p.setDescription(i.getDescription());
				p.setDiscount(i.getDiscount());
				p.setName(i.getName());
				p.setPrice(i.getPrice());
				p.setProductId(i.getProductId());
				p.setQuantity(i.getQuantity());
				
				sellingProducts.add(p);
			}
			
			seller.setProducts(sellingProducts);
			
		}
		
		return seller;
	}

	@Override
	public Boolean checkAvailabilityOfEmailId(String emailId) {
		
		Boolean flag = false;
		
		SellerEntity sellerEntity = null;

		emailId = emailId.toLowerCase();

		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<SellerEntity> criteria = builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root = criteria.from(SellerEntity.class);
		criteria.where(builder.equal(root.get("emailId"), emailId));
		sellerEntity = session.createQuery(criteria).uniqueResult();

		if(sellerEntity == null)
			flag = true;

		return flag;
	}

	@Override
	public Boolean checkRegisteredPhoneNumber(String phoneNumber) {
		
		Boolean flag = false;
		
		SellerEntity sellerEntity = null;
		
		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<SellerEntity> criteria = builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root = criteria.from(SellerEntity.class);
		criteria.where(builder.equal(root.get("phoneNumber"), phoneNumber));
		sellerEntity = session.createQuery(criteria).uniqueResult();
		if(sellerEntity == null)
			flag = true;

		return flag;
	}

	@Override
	public String registerNewSeller(Seller seller) {
		
		String registeredWithEmailId = null;
		
		Session session = sessionFactory.getCurrentSession();
		
		SellerEntity sellerEntity = new SellerEntity();
		
		sellerEntity.setAddress(seller.getAddress());
		sellerEntity.setEmailId(seller.getEmailId().toLowerCase());
		sellerEntity.setName(seller.getName());
		sellerEntity.setPassword(seller.getPassword());
		sellerEntity.setPhoneNumber(seller.getPhoneNumber());
		sellerEntity.setProductEntities(null);
		
		registeredWithEmailId = (String) session.save(sellerEntity);
		
		return registeredWithEmailId;
	}
	
	@Override
	public Seller getSellerByPhoneNo(String phoneNumber) {
		
		Seller seller=null;

		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<SellerEntity> criteria = builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root = criteria.from(SellerEntity.class);
		criteria.where(builder.equal(root.get("phoneNumber"), phoneNumber) );
		SellerEntity sellerEntity = session.createQuery(criteria).uniqueResult();
		if(sellerEntity!=null){
			seller = new Seller();
			seller.setAddress(sellerEntity.getAddress());
			seller.setEmailId(sellerEntity.getEmailId());
			seller.setName(sellerEntity.getName());
			seller.setPhoneNumber(sellerEntity.getPhoneNumber());
		}
			
		return seller;
	}
	
	@Override
	public void updateProfile(Seller seller) {
		
		Session session  = sessionFactory.getCurrentSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();
 
		CriteriaQuery<SellerEntity> criteria = builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root = criteria.from(SellerEntity.class);
		criteria.where(builder.equal(root.get("emailId"), seller.getEmailId().toLowerCase()));
		SellerEntity sellerEntity = session.createQuery(criteria).uniqueResult();
		
		sellerEntity.setAddress(seller.getAddress());
		sellerEntity.setName(seller.getName());
		sellerEntity.setPhoneNumber(seller.getPhoneNumber());

	}
	
	@Override
	public void changePassword(String sellerEmailId, String newHashedPassword) {
		
		SellerEntity sellerEntity = null;

		Session session  = sessionFactory.getCurrentSession();

		sellerEntity = session.get(SellerEntity.class, sellerEmailId);		
		sellerEntity.setPassword(newHashedPassword); 
		
	}
}
