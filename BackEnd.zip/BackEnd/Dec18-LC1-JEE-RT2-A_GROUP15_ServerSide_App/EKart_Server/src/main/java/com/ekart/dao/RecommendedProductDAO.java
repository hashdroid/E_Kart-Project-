package com.ekart.dao;

import java.util.List;

import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;

public interface RecommendedProductDAO {
	
	public List<RecommendedProduct> getRecommendedProducts(String emailId);
	public Integer removeRecommendedProducts(String emailId,Integer recommendationId);
	public Integer addRecommendedProducts(String emailId, Integer productId);
	public List<Product> getAllProducts(String emailId);
	
}
