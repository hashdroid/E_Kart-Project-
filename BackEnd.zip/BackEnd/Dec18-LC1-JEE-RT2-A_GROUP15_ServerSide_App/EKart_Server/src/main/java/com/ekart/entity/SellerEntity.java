package com.ekart.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Column;


@Entity
@Table (name="EKART_SELLER")
public class SellerEntity {
	@Id
	@Column(name = "SELLER_EMAIL_ID")
	private String emailId;
	
	@Column(name="SELLER_NAME")
	private String name;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="SELLER_PHONE_NUMBER")
	private String phoneNumber;
	
	@Column(name="SELLER_ADDRESS")
	private String address;

	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "EK_SELLER_PRODUCT_MAPPING", 
	joinColumns= { @JoinColumn(name = "SELLER_EMAIL_ID")},
	inverseJoinColumns = {@JoinColumn(name = "PRODUCT_ID")})
	private List<ProductEntity> productEntities;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="EK_SELLER_PRODUCT_RCOMND_MAPP",
	joinColumns={@JoinColumn(name="SELLER_EMAIL_ID")},
	inverseJoinColumns={@JoinColumn(name="RECOMMENDATION_ID")})
	private List<RecommendedProductEntity> recommendedProductEntities;
	
	
	public List<ProductEntity> getProductEntities() {
		return productEntities;
	}

	public void setProductEntities(List<ProductEntity> productEntities) {
		this.productEntities = productEntities;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<RecommendedProductEntity> getRecommendedProductEntities() {
		return recommendedProductEntities;
	}

	public void setRecommendedProductEntities(
			List<RecommendedProductEntity> recommendedProductEntities) {
		this.recommendedProductEntities = recommendedProductEntities;
	}
	
	
	

}
