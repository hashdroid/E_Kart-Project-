package com.ekart.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Seller;
import com.ekart.service.SellerService;
import com.ekart.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("SellerAPI")
public class SellerAPI {
	
	@Autowired
	private Environment environment;
	
	
	@RequestMapping(value = "registerSeller", method = RequestMethod.POST)
	public ResponseEntity<String> registerNewSeller(@RequestBody Seller seller) throws Exception {

		
		try
		{
			SellerService sellerService = ContextFactory.getContext().getBean(SellerService.class);
			
			String registeredWithEmailID = sellerService.registerNewSeller(seller);
			registeredWithEmailID = environment.getProperty("SellerAPI.SELLER_REGISTRATION_SUCCESS")+registeredWithEmailID;
			return new ResponseEntity<String>(registeredWithEmailID, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "sellerLogin", method = RequestMethod.POST)
	public ResponseEntity<?> authenticateSeller(@RequestBody Seller seller) throws Exception {

		
		try
		{
			SellerService sellerLoginService = ContextFactory.getContext().getBean(SellerService.class);
			
			Seller sellerFromDB =  sellerLoginService.authenticateSeller(seller.getEmailId().toLowerCase(), seller.getPassword());
			return new ResponseEntity<Seller>(sellerFromDB, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}	

	@RequestMapping(value = "updateProfile", method = RequestMethod.POST)
	public ResponseEntity<String> updateSellerDetails(@RequestBody Seller seller) throws Exception {

		try
		{ 
			SellerService sellerService = ContextFactory.getContext().getBean(SellerService.class);
			
			sellerService.updateProfile(seller);
			String modificationSuccessMsg = environment.getProperty("SellerAPI.SELLER_DETAILS_UPDATION_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
			
		}
	}
	
	@RequestMapping(value = "changePassword", method = RequestMethod.POST)
	public ResponseEntity<String> changePassword(@RequestBody Seller seller) throws Exception {
		try
		{
			SellerService sellerService = ContextFactory.getContext().getBean(SellerService.class);
			
			sellerService.changePassword(seller.getEmailId(), seller.getPassword(), seller.getNewPassword());
			String modificationSuccessMsg = environment.getProperty("SellerAPI.SELLER_PASSWORD_CHANGE_SUCCESS");
			return new ResponseEntity<String>(modificationSuccessMsg, HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			String message = environment.getProperty(e.getMessage());
			
			return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
		}
	}
	
}
