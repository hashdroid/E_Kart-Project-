package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.OrderEntity;
import com.ekart.entity.ProductEntity;
import com.ekart.model.Order;
import com.ekart.model.OrderStatus;
import com.ekart.model.Product;

@Repository(value = "sellerOrderDAO")
public class SellerOrderDAOImpl implements SellerOrderDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void modifyOrderStatus(Integer orderId, OrderStatus orderStatus) {

		Session session = sessionFactory.getCurrentSession();
		
		OrderEntity orderEntity = session.get(OrderEntity.class, orderId);
		
		orderEntity.setOrderStatus(orderStatus);
		
	}

	@Override
	public List<Order> getOrdersForProducts(List<Integer> productIds) {
		
		Session session  = sessionFactory.getCurrentSession();
		
		List<OrderEntity> allOrderEntities = new ArrayList<>();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		
		for (Integer productId : productIds) {
			CriteriaQuery<OrderEntity> criteria = builder.createQuery(OrderEntity.class);
			Root<OrderEntity> root = criteria.from(OrderEntity.class);
			ProductEntity productEntity = new ProductEntity();
			productEntity.setProductId(productId);
			criteria.where(builder.equal(root.get("productEntity"), productEntity));
			List<OrderEntity> orderEntities = session.createQuery(criteria).getResultList();
			allOrderEntities.addAll(orderEntities);
		}
		
		List<Order> orders = new ArrayList<>();
		for (OrderEntity orderEntity : allOrderEntities) {
			Order order = new Order();
			order.setAddressId(orderEntity.getAddressId());
			order.setDateOfOrder(orderEntity.getDateOfOrder());
			order.setOrderId(orderEntity.getOrderId());
			order.setOrderNumber(orderEntity.getOrderNumber());
			order.setOrderStatus(orderEntity.getOrderStatus().toString());
				ProductEntity productEntity = orderEntity.getProductEntity();
				Product product = new Product();
				product.setBrand(productEntity.getBrand());
				product.setCategory(productEntity.getCategory());
				product.setDescription(productEntity.getDescription());
				product.setDiscount(productEntity.getDiscount());
				product.setName(productEntity.getName());
				product.setPrice(productEntity.getPrice());
				product.setProductId(productEntity.getProductId());
				product.setQuantity(productEntity.getQuantity());
			order.setProduct(product);
			order.setQuantity(orderEntity.getQuantity());
			order.setTotalPrice(orderEntity.getTotalPrice());
			order.setPaymentThrough(orderEntity.getPaymentThrough());
			order.setDataOfDelivery(orderEntity.getDataOfDelivery());
			orders.add(order);
		}
		
		return orders;
	}

}
