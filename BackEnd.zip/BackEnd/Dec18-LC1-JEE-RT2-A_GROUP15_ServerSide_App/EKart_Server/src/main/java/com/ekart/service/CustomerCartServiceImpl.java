package com.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.CustomerCartDAO;
import com.ekart.model.CustomerCart;
import com.ekart.model.Product;

@Service(value = "customerCartService")
@Transactional(readOnly = true)
public class CustomerCartServiceImpl implements CustomerCartService {

	@Autowired
	private CustomerCartDAO customerCartDAO;
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void addProductToCart(String customerEmailId, CustomerCart customerCart) throws Exception {

		List<CustomerCart> customerCartsFromDB = customerCartDAO.getCustomerCart(customerEmailId);
		
		for (CustomerCart customecCartFromDB : customerCartsFromDB) {

			if(customecCartFromDB.getProduct().getProductId().equals(customerCart.getProduct().getProductId()))
				throw new Exception("CustomerCartService.PRODUCT_PRESENT_IN_CART");
		}
		
		Product productFromDao = customerCartDAO.getProductById(customerCart.getProduct().getProductId());
		if(productFromDao.getQuantity() < customerCart.getQuantity())
			throw new Exception("CustomerCartService.INSUFFICIENT_STOCK");
		
		customerCartDAO.addProductToCart(customerEmailId, customerCart);

	}




	@Override
	public List<CustomerCart> getCustomerCart(String customerEmailId) throws Exception {

		List<CustomerCart> list = customerCartDAO.getCustomerCart(customerEmailId);
		if(list==null || list.isEmpty())
		{
			throw new Exception("CustomerCartService.NO_PRODUCT_ADDED_TO_CART");
		}

		return list;
	}




	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void modifyQuantityToCart(Integer cartId, Integer quantity, Integer productId) throws Exception {

		Product product  = customerCartDAO.getProductById(productId);
		if(quantity>product.getQuantity())
			throw new Exception("CustomerCartService.INSUFFICIENT_STOCK");
		
		customerCartDAO.modifyQuantityToCart(cartId, quantity);

	}





	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void deleteProductFromCart(String customerEmailId, Integer cartId) {
		customerCartDAO.deleteProductFromCart(customerEmailId, cartId);
	}

}
