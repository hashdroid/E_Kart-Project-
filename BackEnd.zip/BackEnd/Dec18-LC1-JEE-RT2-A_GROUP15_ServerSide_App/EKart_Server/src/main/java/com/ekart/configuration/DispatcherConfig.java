package com.ekart.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * This class is a configuration class for Dispatcher Servlet.  
 * 
 * @EnableWebMvc
 * Adding this annotation imports the 
 * Spring MVC configuration from WebMvcConfigurationSupport.
 * 
 * @ComponentScan
 * It is to scan the classes in the package 
 * "com.amigowallet.api". This package is given
 * as base package to this annotation.
 * 
 * @author ETA_JAVA
 *
 */
@EnableWebMvc
@ComponentScan(basePackages = "com.ekart.api")
public class DispatcherConfig
{

}
