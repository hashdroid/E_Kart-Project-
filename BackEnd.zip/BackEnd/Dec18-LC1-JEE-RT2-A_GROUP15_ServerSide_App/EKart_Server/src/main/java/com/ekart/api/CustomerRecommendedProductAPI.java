package com.ekart.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.RecommendedProduct;

import com.ekart.service.CustomerRecommendationProductServiceImpl;
import com.ekart.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("customerRecommendedProductAPI")
public class CustomerRecommendedProductAPI {
	
	Environment environment;
	@RequestMapping(value = "customerRecommendedProduct", method = RequestMethod.GET)
	public ResponseEntity<List<RecommendedProduct>> viewRecommendedProduct() throws Exception{
	environment=ContextFactory.getContext().getEnvironment();
		
		try{

			CustomerRecommendationProductServiceImpl customer=ContextFactory.getContext().getBean(CustomerRecommendationProductServiceImpl.class);
			List<RecommendedProduct> list=customer.viewRecommendedProduct();
			
			return new ResponseEntity<List<RecommendedProduct>>(list, HttpStatus.OK);
		}catch(Exception e){
			
			String message=environment.getProperty(e.getMessage());
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			recommendedProduct.getProduct().setErrorMessage(message);
			List<RecommendedProduct> list=new ArrayList<>();
			list.add(recommendedProduct);
			return new ResponseEntity<List<RecommendedProduct>>(list, HttpStatus.BAD_REQUEST);
		}
	}
}
