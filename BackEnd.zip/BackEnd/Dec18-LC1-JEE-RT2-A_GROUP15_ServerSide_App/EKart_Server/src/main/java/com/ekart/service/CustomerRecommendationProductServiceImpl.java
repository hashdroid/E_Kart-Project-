package com.ekart.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.CustomerRecommendationProductDAO;
import com.ekart.model.RecommendedProduct;

@Service(value="customerRecommendationProductService")
@Transactional(readOnly=true)
public class CustomerRecommendationProductServiceImpl implements CustomerRecommendationProductService{
	@Autowired
	private CustomerRecommendationProductDAO customerRecommendationProductDAO;
	
	public List<RecommendedProduct> viewRecommendedProduct() throws Exception{
		List<RecommendedProduct> productList=customerRecommendationProductDAO.viewRecommendedProduct();
		if(productList==null){
			throw new Exception("CustomerRecommendationProductService.NO_DEALS");
		}
	return productList;	
	}
}
