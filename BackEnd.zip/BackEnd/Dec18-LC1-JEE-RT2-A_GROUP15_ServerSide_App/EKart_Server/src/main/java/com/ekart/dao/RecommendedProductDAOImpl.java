package com.ekart.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;





import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.ProductEntity;
import com.ekart.entity.RecommendedProductEntity;
import com.ekart.entity.SellerEntity;
import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;

@Repository(value="sellerRecommendationDAO")
public class RecommendedProductDAOImpl implements RecommendedProductDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<RecommendedProduct> getRecommendedProducts(String emailId){
		
		Session session=sessionFactory.getCurrentSession();
		List<RecommendedProductEntity> recommendProductEntityList=new ArrayList<>();
		
		SellerEntity sellerEntity=session.get(SellerEntity.class,emailId);
		if(sellerEntity==null){
			return null;
		}
		else{
			recommendProductEntityList=sellerEntity.getRecommendedProductEntities();
			
			List<RecommendedProduct> recommendedProducts=new ArrayList<>();
			
			for(RecommendedProductEntity rpe:recommendProductEntityList){
				if(rpe.getRecommendationStatus().equals("ACTIVE")){
					RecommendedProduct rp=new RecommendedProduct();
					rp.setrecommendationId(rpe.getRecommendationId());
					rp.setrecommendationStatus(rpe.getRecommendationStatus());
					rp.setrecommendationTimestamp(rpe.getRecommendationTimestamp());
					
					Product product=new Product();
					product.setBrand(rpe.getProductEntity().getBrand());
					product.setCategory(rpe.getProductEntity().getCategory());
					product.setDescription(rpe.getProductEntity().getDescription());
					product.setDiscount(rpe.getProductEntity().getDiscount());
					product.setName(rpe.getProductEntity().getName());
					product.setPrice(rpe.getProductEntity().getPrice());
					product.setProductId(rpe.getProductEntity().getProductId());
					product.setQuantity(rpe.getProductEntity().getQuantity());
					
					rp.setProduct(product);
					recommendedProducts.add(rp);
				}
			}
			return recommendedProducts;
		}
		
	}
	
	@Override
	public Integer removeRecommendedProducts(String emailId,Integer recommendationId){
		Session session=sessionFactory.getCurrentSession();
		
		
		SellerEntity sellerEntity=session.get(SellerEntity.class,emailId);
		if(sellerEntity!=null){
			List<RecommendedProductEntity> recommendedProductEntities=new ArrayList<>();
			recommendedProductEntities=sellerEntity.getRecommendedProductEntities();
			
			for(RecommendedProductEntity recommendedProductEntity:recommendedProductEntities){
				if(recommendedProductEntity.getRecommendationId().equals(recommendationId) && recommendedProductEntity.getRecommendationStatus().equals("ACTIVE")){
					recommendedProductEntity.setRecommendationStatus("INACTIVE");
					session.persist(recommendedProductEntity);
					return recommendationId;
				}
			}
		}
		return 0;
	}
	
	@Override
	public Integer addRecommendedProducts(String emailId, Integer productId){
		Session session=sessionFactory.getCurrentSession();
		SellerEntity sellerEntity=session.get(SellerEntity.class,emailId);
		RecommendedProductEntity recommendedProductEntity=new RecommendedProductEntity();
		List<RecommendedProductEntity> recommendedProductEntityList=new ArrayList<>();
		List<RecommendedProduct>alreadyList=this.getRecommendedProducts(emailId);
		List<Integer>productIdList=new ArrayList<>();
		for(RecommendedProduct i:alreadyList)
		{
			productIdList.add(i.getProduct().getProductId());
		}
		
		if(!productIdList.contains(productId)){
		recommendedProductEntityList=sellerEntity.getRecommendedProductEntities();
		
		for(RecommendedProductEntity rip:recommendedProductEntityList){
			if(rip.getProductEntity().getProductId().equals(productId)){
				continue;
			}
			else{
				ProductEntity productEntity=session.get(ProductEntity.class,productId);
				recommendedProductEntity.setProductEntity(productEntity);
				recommendedProductEntity.setRecommendationStatus("ACTIVE");
				recommendedProductEntity.setRecommendationTimestamp(LocalDateTime.now());
				
				sellerEntity.getRecommendedProductEntities().add(recommendedProductEntity);
				
				
				return (Integer)session.save(recommendedProductEntity);
			}
		}
		}
		
		return recommendedProductEntity.getRecommendationId();
		
	}
	
	@Override
	public List<Product> getAllProducts(String emailId){
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder=session.getCriteriaBuilder();
		
		CriteriaQuery<ProductEntity> criteriaQuery=criteriaBuilder.createQuery(ProductEntity.class);
		criteriaQuery.from(ProductEntity.class);
		List<ProductEntity> productList=session.createQuery(criteriaQuery).getResultList();
		List<Product> listProducts=new ArrayList<>();
		List<Product> finalList=new ArrayList<>();
		
		for(ProductEntity productEntity:productList){
			Product product=new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setDiscount(productEntity.getDiscount());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			
			listProducts.add(product);
		}
		SellerEntity sellerEntity=session.get(SellerEntity.class,emailId);
		if(sellerEntity!=null){
			List<RecommendedProductEntity> listOfRecommended=sellerEntity.getRecommendedProductEntities();
			for(RecommendedProductEntity i:listOfRecommended){
				for(Product j:listProducts){
					if(!i.getProductEntity().getProductId().equals(j.getProductId())){
						if(!finalList.contains(j))
							{finalList.add(j);}
					}
				}
			}
			return finalList;
		}
		else{
			return null;
		}
		
	}

}
