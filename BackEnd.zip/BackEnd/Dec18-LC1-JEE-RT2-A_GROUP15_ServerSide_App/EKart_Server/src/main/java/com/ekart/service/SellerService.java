package com.ekart.service;

import com.ekart.model.Seller;

public interface SellerService {
	
	public Seller authenticateSeller(String emailId, String password) throws Exception;

	public String registerNewSeller(Seller seller) throws Exception ;
	
	public void updateProfile(Seller seller) throws Exception;
	
	public void changePassword(String sellerEmailId, String currentPassword, String newPassword) throws Exception;
}
