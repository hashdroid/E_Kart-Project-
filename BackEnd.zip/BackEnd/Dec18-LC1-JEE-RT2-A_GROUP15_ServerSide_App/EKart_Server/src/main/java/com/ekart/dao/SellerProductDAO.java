package com.ekart.dao;

import java.util.List;

import com.ekart.model.Product;

public interface SellerProductDAO {

	public Integer addNewProduct(Product product, String sellerEmailId);
	
	public Product modifyProductDetails(Product product, String sellerEmailId);
	
	public Integer removeProduct(Integer productId, String sellerEmailId);
	
	public List<String> getProductCategoryList();
}
