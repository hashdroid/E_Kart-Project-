package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.ProductEntity;
import com.ekart.model.Product;
@Repository(value = "customerProductDAO")
public class CustomerProductDAOImpl implements CustomerProductDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public List<Product> getAllProducts() {

		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		
		CriteriaQuery<ProductEntity> criteria = builder.createQuery(ProductEntity.class);
		criteria.from(ProductEntity.class);
		List<ProductEntity> productList= session.createQuery(criteria).getResultList();
		
		List<Product> listProducts = new ArrayList<Product>();
		for (ProductEntity productEntity : productList) {
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			product.setDiscount(productEntity.getDiscount());

			listProducts.add(product);
		}
		return listProducts;
	}
}
