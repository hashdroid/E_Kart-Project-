package com.ekart.api;

import java.util.ArrayList;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.ekart.model.Product;
import com.ekart.model.RecommendedProduct;
import com.ekart.model.Seller;
import com.ekart.service.SellerRecommendationsService;
import com.ekart.service.SellerRecommendationsServiceImpl;
import com.ekart.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping(value="SellerRecommendationsAPI")
public class SellerRecommendationsAPI {
	@Autowired
	private Environment environment;
	SellerRecommendationsService service=ContextFactory.getContext().getBean(SellerRecommendationsServiceImpl.class);
	@RequestMapping(value="view",method=RequestMethod.POST)
	public ResponseEntity<List<RecommendedProduct>> getRecommendedProducts(@RequestBody Seller seller)
	{
		ResponseEntity<List<RecommendedProduct>> responseEntity=null;
		try{
			List<RecommendedProduct> viewProducts=service.getRecommendedProducts(seller.getEmailId());
			responseEntity=new ResponseEntity<List<RecommendedProduct>>(viewProducts,HttpStatus.OK);
		}
		catch(Exception e){
			environment=ContextFactory.getContext().getEnvironment();
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			List<RecommendedProduct> product =new ArrayList<RecommendedProduct>();
			
			recommendedProduct.setMessage(environment.getProperty(e.getMessage()));
			product.add(recommendedProduct);
			responseEntity=new ResponseEntity<List<RecommendedProduct>>(product, HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@RequestMapping(value="remove/{emailId}/{recommendedId}",method=RequestMethod.POST)
	public ResponseEntity<String> removeRecommendedProducts(@PathVariable(value="recommendedId") Integer recommendedId,@PathVariable(value="emailId") String sellerEmailId)throws Exception
	{
		ResponseEntity<String> responseEntity;
		
		try{
			environment=ContextFactory.getContext().getEnvironment();
			service=ContextFactory.getContext().getBean(SellerRecommendationsServiceImpl.class);
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			String rid=service.removeRecommendedProducts(sellerEmailId, recommendedId);
			String message=environment.getProperty("SellerRecommendationsService.SUCCESSFULLY_REMOVED")+":Removed Product Id: "+rid;
			recommendedProduct.setMessage(message);
			responseEntity=new ResponseEntity<String>(message,HttpStatus.OK);
		}catch(Exception e){
			environment=ContextFactory.getContext().getEnvironment();
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			recommendedProduct.setMessage(environment.getProperty(e.getMessage()));
			responseEntity=new ResponseEntity<String>(recommendedProduct.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	@RequestMapping(value="addProducts/{emailId}/{productId}",method=RequestMethod.POST)
	public ResponseEntity<String> addRecommendedProducts(@PathVariable(value="emailId") String emailId,@PathVariable(value="productId") Integer productId  )
	{
		ResponseEntity<String> responseEntity;
		
		try{
			environment=ContextFactory.getContext().getEnvironment();
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			Integer id=service.addRecommendedProducts(emailId,productId);
			String successMessage=environment.getProperty("SellerRecommendationsService.SUCCESSFULLY_ADDED")+":Product Id:"+id;
			recommendedProduct.setMessage(successMessage);
			responseEntity=new ResponseEntity<String>(successMessage,HttpStatus.OK);
		}catch(Exception e){
			environment=ContextFactory.getContext().getEnvironment();
			String message=environment.getProperty("SellerRecommendationsService.ALREADY_RECOMMENDED");
			RecommendedProduct recommendedProduct=new RecommendedProduct();
			recommendedProduct.setMessage(message);
			responseEntity=new ResponseEntity<String>(recommendedProduct.getMessage(), HttpStatus.BAD_REQUEST);
			
		}
		return responseEntity;
	}
	
	@RequestMapping(value="displayAllProducts",method=RequestMethod.POST)
	public ResponseEntity<List<Product>> getAllProducts(@RequestBody Seller seller){
		ResponseEntity<List<Product>> responseEntity;
		try{
			List<Product> productList=service.getAllProducts(seller.getEmailId());
			responseEntity=new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
		}
		catch(Exception e){
			List<Product> productList=new ArrayList<>();
			String errorMessage=environment.getProperty(e.getMessage());
			
			Product product=new Product();
			product.setErrorMessage(errorMessage);
			productList.add(product);
			responseEntity=new ResponseEntity<List<Product>>(productList,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
}
