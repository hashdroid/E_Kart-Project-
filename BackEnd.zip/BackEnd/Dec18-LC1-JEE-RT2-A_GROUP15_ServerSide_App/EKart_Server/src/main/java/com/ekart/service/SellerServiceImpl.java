package com.ekart.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ekart.dao.SellerDAO;
import com.ekart.model.Seller;
import com.ekart.utility.HashingUtility;
import com.ekart.validator.SellerValidator;


@Service( value = "sellerService" )
@Transactional(readOnly = true)
public class SellerServiceImpl implements SellerService{


	@Autowired
	private SellerDAO sellerDAO;
	
	@Override
	public Seller authenticateSeller(String emailId, String password)
			throws Exception {
		
		Seller seller = null;

		SellerValidator.validateSellerForLogin(emailId, password);

		String passwordFromDB = sellerDAO.getPasswordOfSeller(emailId);
		if(passwordFromDB!=null){
			String hashedPassword = HashingUtility.getHashValue(password);

			if(hashedPassword.equals(passwordFromDB)){
				seller  = sellerDAO.getSellerByEmailId(emailId);
			}
			else
				throw new Exception ("SellerService.INVALID_CREDENTIALS");
		}
		else
			throw new Exception ("SellerService.INVALID_CREDENTIALS");

		return seller;
	}
	


	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public String registerNewSeller(Seller seller) throws Exception{
		
		String registeredWithEmailId = null;
		
		SellerValidator.validateSellerForRegistration(seller);
		Boolean bool = sellerDAO.checkAvailabilityOfEmailId(seller.getEmailId());
		if(bool){
			
			if(sellerDAO.checkRegisteredPhoneNumber(seller.getPhoneNumber())){
				String emailIdToDB = seller.getEmailId().toLowerCase();
				String passwordToDB = HashingUtility.getHashValue(seller.getPassword());
				
				seller.setEmailId(emailIdToDB);
				seller.setPassword(passwordToDB);
				
				registeredWithEmailId = sellerDAO.registerNewSeller(seller);
				
			}
			else{
				throw new Exception("SellerService.PHONE_NUMBER_ALREADY_IN_USE");
			}
		}
		else{
			throw new Exception("SellerService.EMAIL_ID_ALREADY_IN_USE");
		}
		
		return registeredWithEmailId;
		
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void updateProfile(Seller seller) throws Exception {
		
		Seller newSeller=null;
		 
		SellerValidator.validateSellerForUpdateProfile(seller);
		newSeller=sellerDAO.getSellerByPhoneNo(seller.getPhoneNumber());
		
		if(newSeller==null){
			sellerDAO.updateProfile(seller);
		}
		else{
			if(newSeller.getEmailId().equals(seller.getEmailId()))
				sellerDAO.updateProfile(seller);
			else
				throw new Exception("SellerService.PHONE_NUMBER_ALREADY_IN_USE");
		}
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRES_NEW)
	public void changePassword(String sellerEmailId, String currentPassword, String newPassword) throws  Exception {
		
		Boolean validPWD = SellerValidator.validatePassword(newPassword);
		if(!validPWD)
			throw new Exception("SellerService.INVALID_NEW_PASSWORD");
		
		String hashedPasswordFromDao = sellerDAO.getPasswordOfSeller(sellerEmailId);
		String hashedCurrentPassword = HashingUtility.getHashValue(currentPassword);
		
		if(!hashedPasswordFromDao.equals(hashedCurrentPassword))
			throw new Exception("SellerService.INVALID_CURRENT_PASSWORD");
		
		if(currentPassword.equals(newPassword))
			throw new Exception("SellerService.OLD_PASSWORD_NEW_PASSWORD_SAME");
		
		String newHashedPassword = HashingUtility.getHashValue(newPassword);
		sellerDAO.changePassword(sellerEmailId, newHashedPassword); 
		
	}

}
