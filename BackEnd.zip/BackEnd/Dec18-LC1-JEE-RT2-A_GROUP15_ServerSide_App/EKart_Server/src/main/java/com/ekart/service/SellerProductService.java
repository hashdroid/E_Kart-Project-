package com.ekart.service;

import java.util.List;

import com.ekart.model.Product;

public interface SellerProductService {
	
	public Integer addNewProduct(Product product,String sellerEmailId) throws Exception;
	
	public Product modifyProductDetails(Product product,String sellerEmailId) throws Exception;
	
	public Integer removeProduct(Integer productId,String sellerEmailId) throws Exception;
	
	public List<String> getProductCategoryList() throws Exception;
}
