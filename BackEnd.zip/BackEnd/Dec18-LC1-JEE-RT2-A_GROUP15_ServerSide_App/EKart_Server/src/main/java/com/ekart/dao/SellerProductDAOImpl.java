package com.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ekart.entity.ProductCategoryEntity;
import com.ekart.entity.ProductEntity;
import com.ekart.entity.SellerEntity;
import com.ekart.model.Product;

@Repository(value = "sellerProductDAO")
public class SellerProductDAOImpl implements SellerProductDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public Integer addNewProduct(Product product, String sellerEmailId) {
		
		Session session = sessionFactory.getCurrentSession();
		ProductEntity newProduct = new ProductEntity();
		newProduct.setBrand(product.getBrand());
		newProduct.setCategory(product.getCategory());
		newProduct.setDescription(product.getDescription());
		newProduct.setDiscount(product.getDiscount());
		newProduct.setName(product.getName());
		newProduct.setPrice(product.getPrice());
		newProduct.setQuantity(product.getQuantity());
		
		SellerEntity sellerEntity = session.get(SellerEntity.class, sellerEmailId.toLowerCase());
		if(sellerEntity!=null){
			sellerEntity.getProductEntities().add(newProduct);
		}
		
		session.persist(sellerEntity);
		ProductEntity lastProduct = sellerEntity.getProductEntities().get(sellerEntity.getProductEntities().size()-1);
		return lastProduct.getProductId();
		
	}
	
	@Override
	public Product modifyProductDetails(Product product, String sellerEmailId) {
		
		Session session = sessionFactory.getCurrentSession();
		SellerEntity sellerEntity= session.get(SellerEntity.class, sellerEmailId);
			List<ProductEntity> productEntities = sellerEntity.getProductEntities();
			
			for (ProductEntity productEntity : productEntities) {
				if(product.getProductId().equals(productEntity.getProductId())){
					productEntity.setBrand(product.getBrand());
					productEntity.setCategory(product.getCategory());
					productEntity.setDescription(product.getDescription());
					productEntity.setDiscount(product.getDiscount());
					productEntity.setName(product.getName());
					productEntity.setPrice(product.getPrice());
					productEntity.setQuantity(product.getQuantity());
				}
			}
		
		return product;
		
	}
	
	@Override
	public Integer removeProduct(Integer productId, String sellerEmailId) {

		Session session = sessionFactory.getCurrentSession();
		SellerEntity sellerEntity= session.get(SellerEntity.class, sellerEmailId);
		
		List<ProductEntity> productEntities = sellerEntity.getProductEntities();
		
		List<ProductEntity> productEntitiesNew = new ArrayList<>(); 
		
		for (ProductEntity productEntity : productEntities) {
			if(!productId.equals(productEntity.getProductId())){
				productEntitiesNew.add(productEntity);
			}
		}
		
		sellerEntity.setProductEntities(productEntitiesNew);
		
		return productId;
	}
	
	@Override
	public List<String> getProductCategoryList() {
		
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		
		CriteriaQuery<ProductCategoryEntity> criteria = builder.createQuery(ProductCategoryEntity.class);
		criteria.from(ProductCategoryEntity.class);
		List<ProductCategoryEntity> productCategoryEntityList= session.createQuery(criteria).getResultList();
		
		List<String> productCategories = new ArrayList<>();
		for (ProductCategoryEntity productCategoryEntity : productCategoryEntityList) {
			productCategories.add(productCategoryEntity.getCategory());
		}
		return productCategories;
	}

}
